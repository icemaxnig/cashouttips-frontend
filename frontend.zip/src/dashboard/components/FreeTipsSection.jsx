import React from "react";
import FreeTips from "./FreeTips";

const FreeTipsSection = () => <FreeTips compact />;

export default FreeTipsSection;
