// 📄 Layout.jsx — Unified App Layout for Branding and Navigation
import React from "react";
import { Link, useLocation } from "react-router-dom";

const Layout = ({ children }) => {
  const location = useLocation();

  const navLinks = [
    { name: "Dashboard", path: "/dashboard" },
    { name: "Subscribe", path: "/subscribe" },
    { name: "My Rollover", path: "/my-rollover" },
    { name: "Booking Codes", path: "/booking-codes" },
    { name: "Referrals", path: "/referrals" },
    { name: "Wallet", path: "/wallet" },
  ];

  return (
    <div className="bg-[#0A0E2C] text-white min-h-screen font-poppins">
      {/* 🟡 Header */}
      <header className="bg-[#0A0E2C] border-b border-gray-800 p-4 flex items-center justify-between">
        <Link to="/dashboard">
          <img
            src="/assets/logo.png"
            alt="CashoutTips Logo"
            className="h-8 sm:h-10"
          />
        </Link>
        <nav className="hidden sm:flex gap-4">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`text-sm font-medium px-3 py-1 rounded-md transition-colors duration-200 hover:text-[#FFD700] ${
                location.pathname.startsWith(link.path)
                  ? "text-[#FFD700] bg-[#1A1E3F]"
                  : "text-gray-300"
              }`}
            >
              {link.name}
            </Link>
          ))}
        </nav>
      </header>

      {/* 🔵 Main Content */}
      <main className="min-h-[calc(100vh-6rem)] px-4 py-6 sm:px-6 lg:px-8">
        {children}
      </main>

      {/* 🔻 Footer */}
      <footer className="bg-[#0A0E2C] border-t border-gray-800 py-4 text-center text-xs text-gray-500">
        &copy; {new Date().getFullYear()} CashoutTips. All rights reserved.
      </footer>
    </div>
  );
};

export default Layout;
