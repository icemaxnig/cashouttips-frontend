// src/pages/MyRollover.jsx
import React, { useEffect, useState } from "react";
import api from "../api";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const MyRollover = () => {
  const [subscription, setSubscription] = useState(null);
  const [tip, setTip] = useState(null);
  const [reminderSet, setReminderSet] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await api.get("/rollover/my");
        // The response is an array of tips, we need to get the active subscription
        const activeSubscription = res.data[0]; // Get the first tip which represents the active subscription
        if (activeSubscription) {
          setSubscription({
            plan: activeSubscription.plan,
            dayIndex: 0, // We'll calculate this based on start date
            startedAt: activeSubscription.createdAt
          });
        } else {
          setSubscription(null);
        }
      } catch (error) {
        console.error("Error fetching rollover data:", error);
        if (error.response?.status === 401) {
          toast.error("Please log in to view your rollover plans");
          navigate("/login");
        } else {
          toast.error("Failed to load rollover data");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  useEffect(() => {
    const fetchTodayTip = async () => {
      if (subscription?.plan?._id) {
        try {
          const res = await api.get("/rollover/today");
          const todayTip = res.data.find((t) => t.plan === subscription.plan._id);
          setTip(todayTip);
        } catch (error) {
          console.error("Error fetching today's tip:", error);
          toast.error("Failed to load today's tip");
        }
      }
    };

    fetchTodayTip();
  }, [subscription]);

  const handleReminder = () => {
    toast.success("You'll be notified when tomorrow's tip drops.");
    setReminderSet(true);
  };

  if (loading) {
    return <div className="text-center mt-8">Loading...</div>;
  }

  if (!subscription || !subscription.plan) {
    return <div className="text-center mt-8">No active rollover plan found.</div>;
  }

  const { plan, startedAt } = subscription;
  const today = new Date();
  const startDate = new Date(startedAt);
  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + (plan.duration || 0));
  const daysLeft = Math.max(0, plan.duration - Math.floor((today - startDate) / (1000 * 60 * 60 * 24)));
  const tipExpiry = tip ? new Date(tip.expiresAt) : null;
  const tipEndingSoon = tipExpiry && tipExpiry - today < 3600000;

  return (
    <div className="bg-white rounded-2xl shadow p-4 w-full max-w-3xl mx-auto">
      <h2 className="text-xl font-bold text-gray-800 mb-4">🔥 Your Active Rollover Plan</h2>

      <div className="text-sm text-gray-700 mb-4">
        <div>🎯 Plan: <strong>{plan.name}</strong></div>
        <div>🧮 Odds: {plan.odds} | 📅 Duration: {plan.duration} days</div>
        <div>📆 Started: {startDate.toDateString()}</div>
        <div>🚀 Progress: Day {Math.floor((today - startDate) / (1000 * 60 * 60 * 24)) + 1} of {plan.duration}</div>
        <div>⏳ Ends: {endDate.toDateString()} ({daysLeft} days left)</div>
      </div>

      <div className="mt-6">
        <h4 className="font-semibold mb-2 text-gray-800">📥 Today's Rollover Tip</h4>
        {tip ? (
          <div className="bg-gray-100 p-3 rounded-lg text-sm text-gray-700">
            <p className="mb-1">🏟️ <strong>{tip.league}</strong></p>
            <p>{tip.teams?.join(" vs ")}</p>
            <p className="text-xs text-gray-500">Code: <strong>{tip.code}</strong></p>
            <p className={`text-xs ${tipEndingSoon ? "text-red-500" : "text-gray-500"}`}>
              Expires at: {tipExpiry.toLocaleTimeString()}
              {tipEndingSoon && " (ending soon!)"}
            </p>
          </div>
        ) : (
          <div className="text-sm text-red-600 mb-3">No tip available yet for today.</div>
        )}

        {!reminderSet && (
          <button
            onClick={handleReminder}
            className="mt-2 w-full bg-yellow-100 hover:bg-yellow-200 text-yellow-800 py-2 text-sm rounded"
          >
            ⏰ Remind Me When Tomorrow's Tip Drops
          </button>
        )}
      </div>
    </div>
  );
};

export default MyRollover;
