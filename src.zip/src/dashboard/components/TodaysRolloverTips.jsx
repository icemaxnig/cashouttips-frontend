// 📄 TodaysRolloverTips.jsx — Branded Dashboard Styling
import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../../api";
import Countdown from "react-countdown";
import { toast } from "react-toastify"; // ✅ correct
import { useAuth } from "../../dashboard/context/AuthContext";

const TodaysRolloverTips = () => {
  const [tips, setTips] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { token } = useAuth();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch today's tips with authentication
        const tipsResponse = await api.get("/rollover/today", {
          headers: { Authorization: `Bearer ${token}` }
        });
        setTips(tipsResponse.data);
      } catch (error) {
        console.error("Error fetching rollover data:", error);
        if (error.response?.status === 401) {
          // Handle unauthorized error silently
          setTips([]);
        } else {
          toast.error("Failed to load today's tips");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token]);

  const renderCountdown = ({ hours, minutes, seconds, completed }) => {
    return completed ? "Expired" : `${hours}h ${minutes}m ${seconds}s left`;
  };

  return (
    <div className="bg-[#FAFAFA] rounded-2xl p-4 shadow-lg border border-[#1F2D5C]">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">🎯 Today's Rollover Tips</h3>
        <div className="flex gap-2">
          <Link
            to="/my-rollover"
            className="text-sm text-blue-600 hover:text-blue-800 font-medium"
          >
            My Rollover
          </Link>
          <Link
            to="/rollover-plans"
            className="text-sm text-blue-600 hover:text-blue-800 font-medium"
          >
            View All
          </Link>
        </div>
      </div>

      {loading && <p className="text-sm text-gray-500">Loading...</p>}

      {!loading && tips.length === 0 && (
        <p className="text-sm text-gray-400 italic">No tips available today.</p>
      )}

      {tips.slice(0, 1).map((tip, i) => {
        const visibleGames = tip.games.slice(0, 2);

        return (
          <div key={i} className="relative bg-white border border-[#1F2D5C] rounded-2xl p-4 shadow-md overflow-hidden">
            <div className="text-sm font-bold text-[#1F2D5C] mb-2 font-poppins">
              🎯 {tip.planName || tip.planType || "Unknown Plan"}
            </div>

            <div className="space-y-2">
              {visibleGames.map((game, j) => (
                <div
                  key={j}
                  className={`rounded-xl p-3 ${tip.isLocked ? 'relative overflow-hidden bg-gray-200' : 'bg-[#F9F9F9] border border-gray-200'}`}
                >
                  {tip.isLocked && <div className="absolute inset-0 bg-white/80 backdrop-blur-md z-10 rounded-xl" />}
                  <div className="relative z-20 space-y-1">
                    <div className="text-xs text-gray-500 font-medium uppercase">{game.league || "-"}</div>
                    <div className="text-sm font-semibold font-poppins">{game.teamA || "-"} vs {game.teamB || "-"}</div>
                    <div className="text-xs">🎯 Prediction: {game.prediction || "-"} • 🧮 Odds: {game.odds || "-"}</div>
                    <div className="text-xs text-gray-600">⏱️ Kickoff: {new Date(game.time).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Always visible */}
            <div className="text-xs mt-4 text-gray-700 relative z-30 space-y-1">
              <div>🏦 <span className="font-semibold">Bookmaker:</span> {tip.bookmaker || "-"}</div>
              <div>📋 <span className="font-semibold">Code:</span> {tip.bookingCode || "-"}</div>
              <div className="text-red-600 font-semibold font-mono">
                ⏳ <Countdown date={new Date(tip.expiresAt)} renderer={renderCountdown} />
              </div>
            </div>

            {tip.isLocked && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 z-40">
                <p className="text-center font-semibold mb-2 text-black bg-white px-4 py-1 rounded-full shadow">🔒 Locked Tip</p>
                <button
                  onClick={() => navigate(`/subscribe/${tip.plan._id}`)}
                  className="bg-[#FFD700] text-black font-bold px-6 py-2 rounded-full shadow hover:bg-yellow-300"
                >
                  Subscribe to Unlock
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default TodaysRolloverTips;
