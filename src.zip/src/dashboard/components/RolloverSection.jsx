import React from "react";
import DashboardRolloverWidget from "./DashboardRolloverWidget";

const RolloverSection = () => (
  <div>
    <DashboardRolloverWidget />
  </div>
);

export default RolloverSection;
