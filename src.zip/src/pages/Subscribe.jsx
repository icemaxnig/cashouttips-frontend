// src/pages/Subscribe.jsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import { useAuth } from "../dashboard/context/AuthContext";

const Subscribe = () => {
  const { token } = useAuth();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  if (!token) return;

  api
    .get("/rollover/plans", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((res) => {
      const plansArray = res.data?.plans;
      if (Array.isArray(plansArray)) {
        setPlans(plansArray);
      } else {
        console.error("Invalid response format:", res.data);
        setPlans([]);
      }
    })
    .catch((err) => {
      console.error("Failed to load plans", err);
      setPlans([]);
    })
    .finally(() => setLoading(false));
}, [token]);


  if (loading) return <div className="text-center mt-10 text-gray-500">Loading plans...</div>;

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold text-yellow-400 mb-6 text-center">🔥 Available Rollover Plans</h1>

      {plans.length === 0 ? (
        <div className="text-center text-gray-500">No rollover plans available right now.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plans.map((plan) => (
            <div key={plan._id} className="bg-white p-4 rounded-xl shadow space-y-2 text-sm">
              <div className="text-lg font-semibold text-gray-800">🎯 {plan.name}</div>
              <div>🧮 Odds: <strong>{plan.odds}</strong></div>
              <div>📆 Duration: <strong>{plan.duration} days</strong></div>
              <div>💳 Price: <strong>₦{plan.price}</strong></div>
              <div>👥 Subscribers: <strong>{plan.fakeSubscribers || 0}+</strong></div>
              <Link
                to={`/subscribe/${plan._id}`}
                className="inline-block mt-2 px-4 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-center"
              >
                View Plan
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Subscribe;
