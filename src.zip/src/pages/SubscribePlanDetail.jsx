// src/pages/SubscribePlanDetail.jsx
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api";
import { toast } from "react-toastify";

const SubscribePlanDetail = () => {
  const { id } = useParams();
  const [plan, setPlan] = useState(null);
  const [stake, setStake] = useState(1000);
  const [wallet, setWallet] = useState({ wallet: 0, bonusWallet: 0 });
  const [tips, setTips] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch plan details
        const planRes = await api.get(`/rollover/plans/${id}`);
        setPlan(planRes.data);

        // Fetch wallet balance
        const walletRes = await api.get("/wallets/balance");
        setWallet(walletRes.data);

        // Fetch today's tips
        const tipsRes = await api.get("/rollover/today");
        setTips(tipsRes.data || []);
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load plan details");
      }
    };

    fetchData();
  }, [id]);

  const getExpectedReturn = (stake, odds, days) => {
    const stakeValue = parseFloat(stake);
    const oddsValue = parseFloat(odds);
    if (isNaN(stakeValue) || isNaN(oddsValue)) return "";
    let compounded = stakeValue;
    for (let i = 0; i < days; i++) compounded *= oddsValue;
    return compounded.toFixed(2);
  };

  const handleSubscribe = () => {
    const token = localStorage.getItem("token");
    api
      .post(
        `/rollover/subscribe`,
        { 
          planId: plan._id,
          walletType: wallet.bonusWallet >= plan.price ? "bonus" : "main"
        },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then(() => {
        toast.success("Subscribed successfully!");
        navigate("/my-rollover");
      })
      .catch((err) => {
        const errorMessage = err.response?.data?.message || "Subscription failed";
        toast.error(errorMessage);
        console.error("Subscription error:", err.response?.data);
      });
  };

  if (!plan) return <div>Loading plan...</div>;

  const todaysTip = tips.find((tip) => tip.plan === plan._id);

  return (
    <div className="bg-white rounded-2xl shadow p-4 w-full max-w-3xl mx-auto">
      <h3 className="text-xl font-semibold text-gray-800 mb-2">🎯 {plan.name} Plan</h3>

      <div className="mb-4 text-sm text-gray-700">
        <div>🧮 Odds: <strong>{plan.odds}</strong></div>
        <div>📅 Duration: <strong>{plan.duration} days</strong></div>
        <div>💳 Price: <strong>₦{plan.price}</strong></div>
        <div>👥 Subscribers: <strong>{plan.fakeSubscribers || 0}+</strong></div>
      </div>

      <div className="bg-gray-50 p-4 rounded mb-4 text-sm text-gray-600">
        <p className="mb-2">
          Our AI-powered rollover plans help you grow your bankroll by reinvesting profits daily.
          Choose your stake amount below and preview your expected returns. Remember, all betting involves risk.
        </p>
        <p className="font-semibold text-gray-700 mb-1">How it Works:</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Subscribe to a plan and get AI-generated betting tips daily.</li>
          <li>Roll over your stake and profits each day for exponential growth.</li>
          <li>Withdraw your initial stake daily to reduce risk exposure.</li>
          <li>Higher odds yield higher returns but carry more risk.</li>
        </ul>
      </div>

      <div className="mb-3">
        <input
          type="number"
          placeholder="Enter Stake to Preview Profit"
          className="w-full p-2 border rounded text-sm"
          value={stake}
          onChange={(e) => setStake(e.target.value)}
        />
        <div className="text-xs text-green-700 mt-1">
          💰 Est. Return in {plan.duration} Days: ₦{getExpectedReturn(stake, plan.odds, plan.duration)}
        </div>
      </div>

      <div className="text-sm text-gray-600 mb-2">
        💼 Wallet: ₦{wallet.wallet.toLocaleString()} | 🎁 Bonus: ₦{wallet.bonusWallet.toLocaleString()}
      </div>

      <button
        onClick={handleSubscribe}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 text-sm rounded"
      >
        Subscribe and View Tips
      </button>

      <div className="mt-6 text-sm text-gray-800">
        <h4 className="font-semibold mb-2">📥 Today's Rollover Tip</h4>
        {todaysTip ? (
          <div className="bg-gray-100 p-3 rounded-lg text-sm text-gray-700">
            <p className="mb-1">🏟️ <strong>{todaysTip.league}</strong></p>
            <p>{todaysTip.teams?.join(" vs ")}</p>
            <p className="text-xs text-gray-500">Code: <strong>{todaysTip.code}</strong></p>
            <p className="text-xs text-gray-500">Expires at: {new Date(todaysTip.expiresAt).toLocaleTimeString()}</p>
          </div>
        ) : (
          <div className="text-sm text-red-600">No tip available yet for this plan today.</div>
        )}
      </div>
    </div>
  );
};

export default SubscribePlanDetail;
